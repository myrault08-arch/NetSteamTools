@echo off
color 0A
title NetSteamTools Installer

set "ZIPFILE=%~dp0NetSteamTools.zip"
set "DEST=C:\"
set "TEMP=C:\NetSteamTools\Temp\"
set "STEAMDIR=C:\Program Files (x86)\Steam"
set "LUADIR=%STEAMDIR%\config\lua"

echo=======================================================================================================================
echo   						NetSteamTools Installer
echo=======================================================================================================================

if not exist "%ZIPFILE%" (
    echo ERROR: NetSteamTools.zip not found in this folder.
    pause
    exit /b
)

echo Creating SteamTools folder: %TEMP%
mkdir "%TEMP%" 2>nul

echo Creating folder: %DEST%
mkdir "%DEST%" 2>nul

echo Extracting files...
powershell -command "Expand-Archive -Path '%ZIPFILE%' -DestinationPath '%DEST%' -Force"

echo.
echo Extraction complete!
echo Files are in: %DEST%

echo.
echo Checking Steam lua folder...
if not exist "%LUADIR%" (
    echo Creating: %LUADIR%
    mkdir "%LUADIR%"
) else (
    echo Folder already exists: %LUADIR%
)

echo.
echo Running installer...
start "" "C:\NetSteamTools\Installer\Application\Setup.exe"

pause